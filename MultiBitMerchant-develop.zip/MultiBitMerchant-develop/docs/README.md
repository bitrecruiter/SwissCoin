## Documentation

MultiBit Merchant is a daunting project so here is a guide to help you get to grips with it.

### Contents

* [Chapter 1 Architecture](1-Architecture.md)
* [Chapter 2 Design Choices](2-Design.md)
* [Chapter 3 Implementation](3-Implementation.md)
