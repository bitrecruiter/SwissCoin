package org.multibit.mbm.client.interfaces.rest.handlers.user;

import org.junit.Ignore;
import org.multibit.mbm.client.interfaces.rest.handlers.BaseHandlerTest;

/**
 * TODO Need to flesh this out
 */
@Ignore
public class CustomerUserHandlerTest extends BaseHandlerTest {

}
