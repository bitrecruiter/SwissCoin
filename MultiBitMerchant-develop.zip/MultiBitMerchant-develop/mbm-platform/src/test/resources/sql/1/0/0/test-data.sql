-- One customer and one merchant
insert into customers (id, openid, email) values ('d6f2dc00-f9d7-11e0-be50-0800200c9a66', 'http://customer.example.org', 'customer@example.org');
insert into customers (id, openid, email) values ('e793c1a1-f9d7-11e0-be50-0800200c9a66', 'http://merchant.example.org', 'merchant@example.org');

