package org.multibit.mbm.services;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class CustomerServiceTest {


  /**
   * Verifies the transaction configuration by Spring
   */
  @Test
  public void testHaveBeenAuthenticated_SpringTx() {

    // TODO Add tests for Cart operations
    assertTrue(true);

  }
}
