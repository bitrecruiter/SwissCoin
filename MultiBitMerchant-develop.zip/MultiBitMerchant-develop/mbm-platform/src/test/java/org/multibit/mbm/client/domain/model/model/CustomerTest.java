package org.multibit.mbm.client.domain.model.model;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class CustomerTest {

  @Test
  public void testPrimaryEmailAddress() {

    // TODO Add cart handling operations

    assertTrue(true);

  }
}
