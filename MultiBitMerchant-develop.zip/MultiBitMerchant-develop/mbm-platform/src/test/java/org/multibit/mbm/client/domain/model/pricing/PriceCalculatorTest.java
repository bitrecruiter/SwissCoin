package org.multibit.mbm.client.domain.model.pricing;

import org.junit.Ignore;

@Ignore
public class PriceCalculatorTest {


}
