package org.multibit.mbm.client.interfaces.rest.resources;
/**
 * <p>This top-level package provides the following to the application through its sub-packages</p>
 * <ul>
 *   <li>JAX-RS annotated RESTful endpoints to access resources</li>
 * </ul>
 */