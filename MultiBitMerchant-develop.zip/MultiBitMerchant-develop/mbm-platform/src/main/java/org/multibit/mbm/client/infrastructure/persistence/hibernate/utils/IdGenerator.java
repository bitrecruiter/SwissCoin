package org.multibit.mbm.client.infrastructure.persistence.hibernate.utils;

public interface IdGenerator {

  Long random();
}
