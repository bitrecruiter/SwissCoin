package org.multibit.mbm.client.infrastructure.persistence;
/**
 * <p>This top-level package provides the following to the application through its sub-packages</p>
 * <ul>
 *   <li>Support for database persistence through ORM framework</li>
 * </ul>
 */