package org.multibit.mbm.client.domain.model.accounting;
/**
 * <p>This top-level package provides the following to the application through its sub-packages</p>
 * <ul>
 *   <li>Access to accounting support (inventory and financial)</li>
 * </ul>
 */