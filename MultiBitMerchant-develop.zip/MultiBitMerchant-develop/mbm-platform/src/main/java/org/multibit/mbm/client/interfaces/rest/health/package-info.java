package org.multibit.mbm.client.interfaces.rest.health;
/**
 * <p>This top-level package provides the following to the application through its sub-packages</p>
 * <ul>
 *   <li>Support for metrics and failure alerts at runtime</li>
 * </ul>
 */