package org.multibit.mbm.client.domain.model.accounting;

/**
 * <p>Service to provide the following to Controllers:</p>
 * <ul>
 * <li>Access to the inventory subsystem</li>
 * </ul>
 * TODO Fill this in
 * @since 0.0.1
 *         
 */
public class InventoryService {

}
