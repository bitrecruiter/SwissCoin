package org.multibit.mbm.client.common.utils;
/**
 * <p>This top-level package provides the following to the application through its sub-packages</p>
 * <ul>
 *   <li>Useful utilities that span all tiers of the application</li>
 * </ul>
 */