multipaper
==========

Multi-signature address (P2SH) paper wallet using bitcore
