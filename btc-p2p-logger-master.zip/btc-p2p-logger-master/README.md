btc-p2p-logger
==============

Watch bitcoin transactions propagate across the network

![Screenshot](https://raw.githubusercontent.com/NathanielWroblewski/btc-p2p-logger/master/screenshot.png)
